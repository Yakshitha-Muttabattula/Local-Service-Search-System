<html>
<body>
<footer
    style="border-top: 1px solid #fff;width: 100%; position: fixed; bottom: 0px;text-align: center;height: 40px; line-height: 40px;background: #ff8c00; ">
    LOCAL SERVICES SEARCH SYSTEM &copy; <?= date("Y") ?>
</footer>
</body>

</html>