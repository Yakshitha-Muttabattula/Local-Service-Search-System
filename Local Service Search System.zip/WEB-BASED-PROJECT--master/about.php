<?php include_once "./include/header.php"; ?>

<div class="container">
    <div class="row">
        <img src="images/homeservies.jpg" class="col-4 card-img-top" alt="Logo">

        <div class="container col-8" style="margin-top: 50px;">
            <div class="card">
                <div class="card-header text-center">
                    <strong>VCE</strong>
                </div>

                <div class="card-body">

                <strong class="card-title">Project Members</strong>
                <ul>
                    <li>1602-17-737-069</li>
                    <li>1602-17-737-120</li>
                    <li>1602-17-737-105</li>
                </ul>
            </div>

            <div class="card-footer text-center">
                Project-Guide: Prof.Dharma Reddy 
            </div>
            </div>
        </div>
    </div>
</div>


<?php include_once "./include/footer.php"; ?>
