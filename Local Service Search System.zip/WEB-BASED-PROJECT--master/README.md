# Local Services System

## Abstract

This is sample local Service booking project. We created this project for theme
 based project. Created with PHP(Without any Frameworks). You basically register
service providers and then can manage bookings or those providers through admin
login.

## License & Copyrights
You can fully copy or redistribute any part including assets, no License or
credit required. 

## Information

#### What is used?
- PHP7, MySQL
- HTML, Bootstrap(Theme is from [Bootswatch](https://bootswatch.com)), Jquery

#### Login Info
- Admin:
  - Mobile No.: 7070808080
  - Password  : admin123
- Providers:
    -  Providers are registered by the admin to create the database.

## Features
- Search for professionals for plumbing, mobile repaires, etc. in your city.
- Register as service provider. Update providers information and password
  through.
  Providers Login.
- Admin can see and manage bookings.
- Admin can see and manage providers.




