<?php include_once "./include/header.php"; ?>

<div class="container">
    <div class="row">
        <div class="container col-8" style="margin-top: 50px;">
            <div class="card">
                <div class="card-header text-center">
                    <strong>Contact Us</strong>
                </div>

                <div class="card-body">
                    <div> Write to us at -localservices@gmail.com <hr>phone no. 7899956767
                    </div>
            </div>
            </div>
        </div>
    </div>
</div>


<?php include_once "./include/footer.php"; ?>
